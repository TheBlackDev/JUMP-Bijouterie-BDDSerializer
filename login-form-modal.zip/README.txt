A Pen created at CodePen.io. You can find this one at http://codepen.io/andytran/pen/GpyKLM.

 This is a material inspired login modal with 2 panels. A login panel, and a registration panel which is hidden by default. The registration panel can be triggered by clicking the visible tab on the right side. Once clicked, the registration panel will slide in and overlap the login panel.

Behance: https://www.behance.net/gallery/30478397/Login-Form-UI-Library

GitHub: https://github.com/andyhqtran/UI-Library/tree/master/Login%20Form